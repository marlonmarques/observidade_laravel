<?php

namespace App\Traits;

use App\Models\Tenant;
use Illuminate\Support\Facades\Log;
use Stancl\Tenancy\Facades\Tenancy;
use Illuminate\Support\Facades\DB;

trait TenantAwareJob
{
    public function handle(): void
    {
        // 1. O "Reset Nuclear" (Obrigatório no FrankenPHP)
        // Isso limpa a sujeira do job anterior ANTES de tentar buscar o tenant
        try {
            DB::connection('pgsql')->statement("SET search_path TO central, public;");
        } catch (\Exception $e) {
            // Ignora erro se a conexão já estiver fechada
        }

        if (!property_exists($this, 'tenantId')) {
            Log::error('Job sem $tenantId.');
            return;
        }

        // 2. Busca manual no banco central
        $tenantData = DB::connection('pgsql')
            ->table('tenants')
            ->where('id', $this->tenantId)
            ->first();

        if (!$tenantData) {
            Log::error("Tenant {$this->tenantId} não encontrado.");
            return;
        }

        // 3. Hidratação Manual
        $tenant = new Tenant((array) $tenantData);
        $tenant->exists = true;
        $tenant->setConnection('pgsql');

        // 4. Inicializa
        Tenancy::initialize($tenant);

        // 5. Executa
        if (method_exists($this, 'handleTenant')) {
            app()->call([$this, 'handleTenant']);
        }

        Tenancy::end();
    }
}
